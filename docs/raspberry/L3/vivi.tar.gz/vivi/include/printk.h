#ifndef _VIVI_PRINTK_H_
#define _VIVI_PRINTK_H_

int printk(const char *fmt, ...);

#endif /* _VIVI_PRINTK_H_ */

