#ifndef _VIVI_TYPES_H_
#define _VIVI_TYPES_H_

#define _LINUX_CONFIG_H
#define __KERNEL__

#include <linux/types.h>

#endif

